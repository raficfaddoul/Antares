﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace Structural
{
    internal class StructuralStatic
    {
        public StructuralStatic() { }
        public void StructureVerification(Structural.Structure structure)
        {
           // 6 solicitations par elements
           // 6 ddl par noeuds

        }
            

    }
}
